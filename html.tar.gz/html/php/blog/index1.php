<?php
   include('./form/session.php');
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', 'webkul');
   define('DB_DATABASE', 'myDB');
   
   // Create connection
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   
   // Check connection
   if ($db->connect_error) 
   {
       die("Connection failed: " . $db->connect_error);
   }

 error_reporting(E_ALL);
 ini_set('display_errors',true);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>BLOG</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
  <script src="./js/social.js"> </script>
  <link rel="stylesheet" type="text/css" href="./style/social.css">	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <style>
    .colu
    {
      border:3px solid red;
      padding: 2%;
      border-radius:10px;
      color:white;
      margin-bottom: 2%;
      margin-left:1%;
      text-align:justify;
      word-break:break-all;
    }
    .container-fluid
    {
      margin-top: 2%;
      padding-right: 6%;
    }
    h2
    {
      width:100%;
      color:#d22d2d;
      
    }
    .textlogin
    {
      
    }
    .bn
    {
      float:left;
      
    }
    .ui
    {
      float:right;
    }
    .t
    {
      font-size:200%;
      text-align:center;
    }
    .pagination
    {
      margin-left:43%;
    }
  </style>
</head>
<body background="bg.jpg">
  <!--NAVBAR-->
  
  <nav class="navbar navbar-expand-md bg-dark navbar-dark sticky-top">
      <nav class="navbar navbar-light ">
          <a class="navbar-brand" href="#">
            <img src="logo-white.png" width="30" height="30" class="d-inline-block align-top" alt="">
            MY BLOG
          </a>
        </nav>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navb" aria-expanded="true">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div id="navb" class="navbar-collapse collapse hide">
      <ul class="nav navbar-nav ml-auto">
          <li class="dropdown">
              <a class="dropdown-toggle nav-link" data-toggle="dropdown" href="#">Category
              <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Technology</a></li>
                <li><a href="#">Food</a></li>
                <li><a href="#">travelling</a></li>
              </ul>
            </li>

        <li class="nav-item">
          <a class="nav-link" href="signup.php"> Signup</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php"><span class="fas fa-sign-in-alt"></span> 
                  <?php 
                          if(isset($_SESSION['login_user']))
                          {
                           
                            echo "Your Profile";
                          }
                          else
                          {
                            echo "Login";
                          }
                            

                   ?> 
      
      </a>
        </li>
      </ul>
    </div>
  </nav>
<!--body-->
  <div class="container-fluid">
     
        <h2><center><u>ALL BLOGS</u></center></h2>

        <div class="row">





        <?php
                      $sql = "SELECT * FROM blog";

                     
                if ($result = $db->query($sql)) {
 
                  while ($row = $result->fetch_assoc()) {
                      $field1name = $row["blogno"];
                      $field2name = $row["useriddb"];
                      $field3name = $row["bdata"];
                      $field4name = $row["title"];
                      $field5name = $row["category"];
                      
                             
                             echo '<div class="col-lg-12 col-sm-5 colu"> 
                             
                                         <p class="textlogin t"><b>'.$field4name.'</b></p> 
                                         <P class="textlogin"> <b> BLOG DESCRIPTION:</b> &emsp; '.$field3name.' </p>
                                        <p class=" ui"> <i><b> by</b> &emsp; '.$field2name.'</i> </p> 
                                        
                              
                               </div>';
                             
   
                      }
                }
                
  ?>
      </div>
  </div>








<!--social icons  -->
  <div class="icon-bar">
      <a  class="facebook"><i class="fa fa-facebook"></i></a> 
      <a class="twitter"><i class="fa fa-twitter"></i></a> 
      <a class="google"><i class="fa fa-google"></i></a> 
      <a  class="linkedin"><i class="fa fa-linkedin"></i></a>
      <a class="youtube"><i class="fa fa-youtube"></i></a> 
</div>
<div class="ffix"><a class="r1" href="http://www.facebook.com"> click here to redirect to facebook</a></div>
<div class="tfix"><a class="r1" href="http://www.twitter.com"> click here to redirect to twitter</a></div>
<div class="gfix"><a class="r1" href="http://www.google.com"> click here to redirect to google</a></div>
<div class="lfix"><a class="r1" href="http://www.linkedin.com"> click here to redirect to linkedin</a></div>
<div class="yfix"><a class="r1" href="http://www.youtube.com"> click here to redirect to youtube</a></div>  
<!--FOOTER-->


<!--pagination-->
<nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
  </ul>
</nav>

    <!-- Footer -->
<footer class="page-footer font-small blue" style="background-color:black">

    <!-- Copyright -->
    <div class="footer footer-copyright text-center py-3">© 2019  Copyright:
      <a href="https://www.webkul.com"> www.webkul.com</a>
    </div>
    <!-- Copyright -->
  
  </footer>
  <!-- Footer -->


</body>
</html>
