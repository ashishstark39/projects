<?php
   include('session.php');
?>
 <?php
 error_reporting(E_ALL);
 ini_set('display_errors',true);
?>
<!DOCTYPE html>
    <head>
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
            <link rel="stylesheet" type="text/css" href="style/stylelogin.css">
            <style>
                  .textlogin
           {
            color: rgb(0, 110, 255);
            font-size:120%;
            display: block;
           }
            </style>
             
    </head>


<html>
        <body>
        <div class="head">WELCOME</div>
        <div class="main">
         
         
         <a href="logout.php">LOGOUT</a>
        
        </form>
        </div>
        </body>
</html> 
