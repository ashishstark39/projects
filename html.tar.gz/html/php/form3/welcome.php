<?php
   include('session.php');
?>
 <?php
 error_reporting(E_ALL);
 ini_set('display_errors',true);
?>
<!DOCTYPE html>
    <head>
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
            <link rel="stylesheet" type="text/css" href="style/stylelogin.css">
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
            <style>
                  .textlogin
           {
            color: rgb(0, 110, 255);
            font-size:120%;
            display: block;
           }
           .pimage
           {
                

                   
           }
           .content {
    text-align: center;
}
.anchor {
    text-align: center;
}
.pimage {
    text-align: center;
}
            </style>
             
    </head>


<html>
        <body>
        <div class="head">LOGIN</div>
        <div class="main container-fluid">
       
                        <div class=pimage>
                        <?php  echo '<img class="img-responsive" src="data:imagedb/jpeg;base64,'.base64_encode( $_SESSION['login_image']).'"/>'; ?>
                        </div>
                        <div class="content">
                        <p class=""> USER NAME: <?php echo $_SESSION['login_user']?> </p><br>
                        <p class=""> USER EMAIL: <?php echo $_SESSION['login_email']?> </p><br>
                        <P class=""> USER ID: <?php echo $_SESSION['login_id']?> </p><br>
                        </div>
                        <br>
                        <div class="anchor">
                        <a href="logout.php">LOGOUT</a>
                        </div>
        </form>
        
        </div>
        </body>
</html> 