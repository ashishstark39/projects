
<!DOCTYPE html>
<html>
<head>
    <title>DOUBLE SINGLE QUOTES</title>
    <style>
        body
        {
            background-color: rgb(122, 186, 243);
            COLOR:white;
        }
    </style>    
</head>
<body>

    <?php



        error_reporting(E_ALL);
        ini_set('display_errors',true);
        ini_set('error_log',true);
        ini_set('error_log','err.log');
        $a=1;
        $b='1';

        echo 'value is $a is $a  in single quotes';
        echo "<br>";
        echo 'while value is $a '."is $a in double quotes";
    ?>

</body>
</html>