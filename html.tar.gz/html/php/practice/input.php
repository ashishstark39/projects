
<!DOCTYPE html>
<html>
<head>
    <title>INPUT</title>
    <style>
        body
        {
            background-color: rgb(122, 186, 243);
        }
    </style>    
</head>
<body>

  
    <div class="cont">
        <form method="GET">
            <label for="name">ENTER YOUR NAME </label><input type="text" id="inp" name="inp" placeholder="your name" name="name" >
            <br>
            <button type="submit">SUBMIT</button>
        </form>
    </div>

    <?php



error_reporting(E_ALL);
ini_set('display_errors',false);
ini_set('error_log',true);
ini_set('error_log','err.log');

echo "you entered: ".$_GET["inp"];
?>

    

</body>
</html>