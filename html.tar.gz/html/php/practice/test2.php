
<!DOCTYPE html>
<html>
<body>

    <?php
        $a=1;
        $b='1';
        $c;
        echo gettype($c);
    ?>

</body>
</html>