<!DOCTYPE html>
<html>
<body>

<?php  
define("$x","5");
$x=$x+10;
echo $x;

?>  

</body>
</html>

