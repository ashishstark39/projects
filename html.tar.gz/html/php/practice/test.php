
<!DOCTYPE html>
<html>
<body>

    <?php
        $txt = "Hello world!";
        $x = 5;
        $y = 10.5;
        $p = "hii $x";
        echo $p."hii";
        if(true===TRUE)
        {
            echo "yes";
        }
    ?>

</body>
</html>