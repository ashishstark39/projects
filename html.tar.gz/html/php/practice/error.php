
<!DOCTYPE html>
<html>
<body>

    <?php



        error_reporting(E_ALL);
        ini_set('display_errors',true);
        ini_set('error_log',true);
        ini_set('error_log','err.log');
        $a=1;
        $b='1';

        echo $c;

    ?>

</body>
</html>