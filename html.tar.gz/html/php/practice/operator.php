
<!DOCTYPE html>
<html>
<body>

    <?php



        error_reporting(E_ALL);
        ini_set('display_errors',true);
        ini_set('error_log',true);
        ini_set('error_log','err.log');
        $a=25;
        $b='hello';
        $c=11.09;
        $d=5;
        echo "<br>";
        echo "<u> int and int </u>";
        echo "<br>";
        echo "addition : ".($a+$d) ;//addition
        echo "<br>";
        echo "concatination : ".($a.$d);//concatination
        echo "<br>";
        echo "modulus : ".($a%$d); //modulo
        echo "<br>";
        echo "Exponentiation : ".($a**$d);   //Exponentiation    
        
        
        echo "<br>";
        echo "<br>";
        echo "<u>int and string</u>";
        echo "<br>";
        echo "addition : ".($a+$b) ;//addition
        echo "<br>";
        echo "concatination : ".($a.$b);//concatination
        echo "<br>";
       // echo "modulus : ".($a%$b); //modulo
        echo "<br>";
        echo "Exponentiation : ".($a**$b);   //Exponentiation  
        
        echo "<br>";
        echo "<br>";
        echo "<u>int and float</u>";
        echo "<br>";
        echo "addition : ".($a+$c) ;//addition
        echo "<br>";
        echo "concatination : ".($a.$c);//concatination
        echo "<br>";
        echo "modulus : ".($a%$c); //modulo
        echo "<br>";
        echo "Exponentiation : ".($a**$c);   //Exponentiation  

        



    ?>

</body>
</html>