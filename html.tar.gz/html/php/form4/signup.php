<!DOCTYPE html>
 <html>
 <head>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="style/style.css">
            <script src="js/signupscript.js"></script>
            <?php
            error_reporting(E_ALL);
            ini_set('display_errors',true);
            ?>
            <style>
            #form2
            {
                margin:10%;
            }
            </style>
</head>
<body>
    <div class="head">SIGN-UP</div>
    <div class="main">
    <form action="data.php" id="form2" name="form2" onsubmit="return validate();" method="post" enctype="multipart/form-data">
                Name: &nbsp;&nbsp;&emsp;&emsp;<input class="inp"  type="text" name="fname" id="fname" placeholder="name" required><p class="n">*name must be in alphabets only</p>
                <br><br>
                E-mail:&nbsp&emsp;&emsp; <input  class="inp" type="email" id="femail" name="femail" placeholder="email" required><p class="e">*enter valid email format</p>
                <br><br>
                Userid:&nbsp &emsp;&emsp;<input title="must contain alphabets only" class="inp" type="text" name="fuserid" id="fuserid" placeholder="userid" required ><p class="u">*userid must contain alphabets onlyy</p>
                <br><br>
                Password:&emsp;<input title="must contain atleast 1 lowercase, 1 uppercase alphabet,1 integer,1 special symbol  " class="inp" type="password" name="fpassword" id="fpassword" placeholder="password" required ><p class="p">*password length minimum 8 characters,must contain 1 lowercase,1 uppercase alphabet,1 special character and 1 integer</p>
                <br><br>
                <input type="file" name="pimage" id="pimage" > <p class="i">*select an image</p>
                <br><br><input class="but2" type="submit" name="submit" value="Submit"><br><br>
                <a href="login.php">Already a user?</a>
    </form>
    </div>
</body>
</html>