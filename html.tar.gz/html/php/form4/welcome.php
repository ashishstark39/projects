<?php
   include('session.php');
?>
 <?php
 error_reporting(E_ALL);
 ini_set('display_errors',true);
?>
<!DOCTYPE html>
<html>
<head>
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
           <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="style/stylelogin.css">
</head>

            
             
   



        <body>
        <div class="head navbar-default">WELCOME</div>
        <div class="main">
       
                        <div class=pimage>
                        <?php  echo '<img class="img-responsive" src="data:imagedb/jpeg;base64,'.base64_encode( $_SESSION['login_image']).'"/>'; ?>
                        </div>
                        <div class="content">
                        <p class="textlogin"> USER NAME: <?php echo $_SESSION['login_user']?> </p>
                        <p class="textlogin"> USER EMAIL: <?php echo $_SESSION['login_email']?> </p>
                        <P class="textlogin"> USER ID: <?php echo $_SESSION['login_id']?> </p>
                        </div>
                        <br>
                        <div class="anchor">
                        <a href="logout.php">LOGOUT</a>
                        </div>
        
        </div>
        </body>
</html> 