<!DOCTYPE html>
 <html>
 <head>
            
            <?php
            error_reporting(E_ALL);
            ini_set('display_errors',true);
            ?>

<style>
body
{
    background-color: aliceblue;
}            
.main
{
    border: 3px solid blue;
    background-color: aqua;
    text-align: center;
}

</style>
</head>

<body>
    <div class="main">
        <form>

        <div class="currdate" method="post">
            <?php
            echo "Today is " . date("d/m/Y") . "<br>";
            ?> 
        </div>
        <div class="userdate">
            <input type="date"><br>
            <input type="submit" value="check diff">
        </div>
        </form>
        <?php
        $date1=date_create($_POST['date']);
        $date2=date_create(date("d/m/Y"));
        $diff=date_diff($date2,$date1);
        echo $diff->format("%a days");
        ?>
        <div class="show_diff">
               
        </div>
    </div>
</body>
</html>
