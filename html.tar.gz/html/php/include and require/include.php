<html>
    <body>
    <h1> include<h1>
    <?php
    include 'file.php';
    echo "Choti is a  $a$b";
    echo "hello";
    echo "hii";
    echo "bye";
    ?>
    </body>
    </html>