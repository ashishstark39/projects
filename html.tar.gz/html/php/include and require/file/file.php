<?php
    $a="beautiful";
    $b="girl";
?>