<html>
    <body>
    <h1> require<h1>
    <?php
    require 'file.php';
    echo "Choti is a  $a$b";

    echo "hello";
    echo "hii";
    echo "bye";
    ?>
    </body>
    </html>