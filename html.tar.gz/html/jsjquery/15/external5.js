
function func()
{
var a=document.forms["form5"]["First_name"].value;
var b=document.forms["form5"]["Last_name"].value;
var c=document.forms["form5"]["Mail_address1"].value;
var d=document.forms["form5"]["Mail_address2"].value;
var e=document.forms["form5"]["City"].value;
var f=document.forms["form5"]["zip"].value;
var g=document.forms["form5"]["E-mail"].value;
var h=document.forms["form5"]["mobile"].value;

if(a=="")
{
alert("first name field is empty enter first name");

}
if(b=="")
{

alert("Last name field is empty enter Last name");
}
if(c=="")
{
alert("Mail address 1 field is empty fill your Mail address 1");

}
if(d=="")
{
alert("Mail address  field is empty fill your Mail address 2");

}
if(e=="")
{
alert("city  field is empty fill your city");

}
if(f=="")
{
alert("zip  field is empty fill your zip");

}

else
{
	if(f.length>6 || f.length<6){alert("zip code cannot be greater or smaller than 6 digit");}
}


if(g=="")
{

alert("E-mail  field is empty fill your E-mail");
}

if(h=="")
{
alert("Mobile no  field is empty fill your Mobile no");
}
else
{       if((Number(h)/1)!==Number(h))
	{
	alert ("enter a number not characters");
		
	}
	else
	{
	if(h.length>10 || h.length<10){
	alert ("enter a 10 digit mobile number");}
	}
}
}




