
function func()
{

var a=document.getElementById("inp").value; 
a=a.toLowerCase();
var b=a.split("").reverse().join("");
	if(a=="" ||a[0]==" ")
	{
	alert("enter a valid string");

	}
	else{
	if(a==b)
	{
	alert("Palindrome");
	}
	else
	{
	alert("Not Palindrome");
	}
	}

}

