
function func()
{

	var a = prompt("Enter a number between 1-7",);
if(a!=null){
	switch(a)
	{
		case "1":
		alert("MONDAY");
		break;
		case "2":
		alert("TUESDAY");
		break;
		case "3":
		alert("WEDNESDAY");
		break;
		case "4":
		alert("THURSDAY");
		break;
		case "5":
		alert("FRIDAY");
		break;
		case "6":
		alert("SATURDAY");
		break;
		case "7":
		alert("SUNDAY");
		break;
		default:
		alert("enter a number 1-7");
		break;
	}
	}
else
{
document.getElementById("text").innerHTML="you didn't enter any value click again";
}	
}




