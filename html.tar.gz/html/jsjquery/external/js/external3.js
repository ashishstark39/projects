
function func()
{

var a=document.getElementById("inp").value; 
if(isNaN(a))
{
alert("\tInvalid Input\nPlease enter a number");
}
else
{
	if(a[0]==" "||a[0]=="")
	{alert("enter a valid no")}
	else{
	if(a%2===0)
	{
	alert("even");
	}
	else
	{
	alert("odd")
	}}
}

}

