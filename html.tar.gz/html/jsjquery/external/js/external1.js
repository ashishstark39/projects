
	function func()
	{
		if(window.confirm("press"))
		{
		window.location.assign("https://www.webkul.com");
		}
		else
		{
		window.location.assign("https://www.webkul.com/blog");
		}


	}

