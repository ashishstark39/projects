
		 $(document).ready(function(){
				$("#coud").show();
				$("#Ind_sd").show();
				$("#pak_sd").hide();
				$("#up_cd").show();
				$("#raj_cd").hide();
				$("#mp_cd").hide();
				$("#bal_cd").hide();
				$("#sin_cd").hide();
				$("#ajk_cd").hide();

		});

		function myFunction() 
		{ 

		  var a=document.getElementById("cou").value;
		  var a1=document.getElementById("Ind_s").value;
		  var a2=document.getElementById("pak_s").value;

		
		if(a=="India")
		{
			

			$(document).change(function(){
		
			
				$("#coud").show();
				$("#Ind_sd").show();
				$("#pak_sd").hide();
				$("#up_cd").show();
				$("#raj_cd").hide();
				$("#mp_cd").hide();
				$("#bal_cd").hide();
				$("#sin_cd").hide();
				$("#ajk_cd").hide();



			});

		
		  if(a1=="uttar pradesh"){
			$(document).change(function(){
		

				$("#coud").show();
				$("#Ind_sd").show();
				$("#up_cd").show();
				$("#raj_cd").hide();
				$("#mp_cd").hide();
				$("#pak_sd").hide();
				$("#bal_cd").hide();
				$("#sin_cd").hide();
				$("#ajk_cd").hide();


			});			
			}

		  if(a1=="rajasthan"){
			$(document).change(function(){
		
			
				$("#coud").show();
				$("#Ind_sd").show();
				$("#up_cd").hide();
				$("#raj_cd").show();
				$("#mp_cd").hide();
				$("#pak_sd").hide();
				$("#bal_cd").hide();
				$("#sin_cd").hide();
				$("#ajk_cd").hide();


			});			
			}

		 if(a1=="madhya pradesh"){
			$(document).change(function(){
		
			
				$("#coud").show();
				$("#Ind_sd").show();
				$("#up_cd").hide();
				$("#raj_cd").hide();
				$("#mp_cd").show();
				$("#pak_sd").hide();
				$("#bal_cd").hide();
				$("#sin_cd").hide();
				$("#ajk_cd").hide();


			});			
			}


			}



		else if(a=="Pakistan")
		{
			$(document).change(function(){
		
			
				$("#coud").show();
				$("#Ind_sd").hide();
				$("#pak_sd").show();
				$("#up_cd").hide();
				$("#raj_cd").hide();
				$("#mp_cd").hide();
				$("#bal_cd").show();
				$("#sin_cd").hide();
				$("#ajk_cd").hide();



			});

		
		  if(a2=="Balochistan"){
			$(document).change(function(){
		

				$("#coud").show();
				$("#Ind_sd").hide();
				$("#pak_sd").show();
				$("#up_cd").hide();
				$("#raj_cd").hide();
				$("#mp_cd").hide();
				$("#bal_cd").show();
				$("#sin_cd").hide();
				$("#ajk_cd").hide();


			});			
			}

		  if(a2=="Sindh"){
			$(document).change(function(){
		
			
				$("#coud").show();
				$("#Ind_sd").hide();
				$("#pak_sd").show();
				$("#up_cd").hide();
				$("#raj_cd").hide();
				$("#mp_cd").hide();
				$("#bal_cd").hide();
				$("#sin_cd").show();
				$("#ajk_cd").hide();


			});			
			}

		 if(a2=="Azad Jammu and Kashmir"){
			$(document).change(function(){
		
			
				$("#coud").show();
				$("#Ind_sd").hide();
				$("#pak_sd").show();
				$("#up_cd").hide();
				$("#raj_cd").hide();
				$("#mp_cd").hide();
				$("#bal_cd").hide();
				$("#sin_cd").hide();
				$("#ajk_cd").show();


			});			
			}


			}



		}
	



	







