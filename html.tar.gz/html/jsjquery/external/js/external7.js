
$(document).ready(function()
{

	$("#one").hide();
	$("#two").hide();
	$("#three").hide();
	$("#four").hide();
	$("#five").hide();
	$("#six	").hide();


	$(".tab1").click(function(){
	$("#one").show();
	$("#two").hide();
	$("#three").hide();
	$("#four").hide();
	$("#five").hide();
	$("#six	").hide();
	});
	$(".tab2").click(function(){
	$("#one").hide();
	$("#two").show();
	$("#three").hide();
	$("#four").hide();
	$("#five").hide();
	$("#six	").hide();
	});
	$(".tab3").click(function(){
	$("#one").hide();
	$("#two").hide();
	$("#three").show();
	$("#four").hide();
	$("#five").hide();
	$("#six	").hide();
	});
	$(".tab4").click(function(){
	$("#one").hide();
	$("#two").hide();
	$("#three").hide();
	$("#four").show();
	$("#five").hide();
	$("#six	").hide();
	});
	$(".tab5").click(function(){
	$("#one").hide();
	$("#two").hide();
	$("#three").hide();
	$("#four").hide();
	$("#five").show();
	$("#six	").hide();
	});
	$(".tab6").click(function(){
	$("#one").hide();
	$("#two").hide();
	$("#three").hide();
	$("#four").hide();
	$("#five").hide();
	$("#six	").show();
	});


});


